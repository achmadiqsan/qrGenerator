QR Code Generator Example
(c)2012 Matthew Hipkin <http://www.matthewhipkin.co.uk>

Simple examples of creating a QR Code using Google Chart APIs in Delphi/Lazarus & FreePascal.
